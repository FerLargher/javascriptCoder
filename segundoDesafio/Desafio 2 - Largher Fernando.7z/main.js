// Simulacion de batalla pokemon

function Pokemon(nombre, numero, tipo, ataque, hp, rival){
    this.nombre = nombre;
    this.numero = numero;
    this.tipo = tipo;
    this.ataque = ataque;
    this.hp = hp;
    this.rival = rival;
}

const bulbasaur = new Pokemon("bulbasaur", 01, "planta", 4, 22, "charmander");
const charmander = new Pokemon("charmander", 04, "fuego", 6, 18, "squirtle");
const squirtle = new Pokemon("squirtle", 07, "agua", 8, 16, "bulbasaur");

function randomInt(max) {
    return Math.floor(Math.random() * max);
}

function elegirPokemon(opcion, inicial){
    let elegido;
    while((opcion >= 1 || opcion <= 3)  && pokemonInicial == false) {
        switch (opcion) {
            case 1:
                alert("Has elegido a " + bulbasaur.nombre + " el pokemon tipo " + bulbasaur.tipo);
                pokemonInicial = true;
                elegido = bulbasaur;
                break;
            case 2:
                alert("Has elegido a " + charmander.nombre + " el pokemon tipo " + charmander.tipo);
                pokemonInicial = true;
                elegido = charmander;
                break;
            case 3:
                alert("Has elegido a " + squirtle.nombre + " el pokemon tipo " + squirtle.tipo);
                pokemonInicial = true;
                elegido = squirtle;
                break;
            default:
                alert("No es momento para estupideces. Elegi tu pokemon.");
                break;
        }
        if(pokemonInicial == false){
            opcion = parseInt(prompt("Te los repito: \n1 - Bulbasaur \n2 - Charmander \n3 - Squirtle"));
        }
    }
    return elegido;
}

function elegirPokemonRival(primerPokemon){
    if(primerPokemon.nombre == "bulbasaur"){
        return charmander;
    } else if (primerPokemon.nombre == "charmander"){
        return squirtle;
    } else if(primerPokemon.nombre == "squirtle"){
        return bulbasaur;
    }
}

function batallaPokemon(primerPokemon, pokemonRival){
    let opcionPelea;
    while(primerPokemon.hp >= 0 && pokemonRival.hp >= 0){
        opcionPelea = prompt("1 - Atacar");
        if(randomInt(3) == 0){
            pokemonRival.hp = pokemonRival.hp - primerPokemon.ataque;
            alert("Tu pokemon golpeo primero y dejo con " + pokemonRival.hp + "de vida a " + pokemonRival.nombre);
        } else if(randomInt(3) == 1){
            primerPokemon.hp = primerPokemon.hp - pokemonRival.ataque;
            alert("El pokemon rival te golpeo primero y dejo con " + primerPokemon.hp + "de vida a " + primerPokemon.nombre);
        } else {
            alert("Ninguno de los pokemon resulto herido.");
        }
    }
    if(primerPokemon.hp > pokemonRival.hp){
        return primerPokemon;
    } else if(pokemonRival.hp > primerPokemon.hp){
        return pokemonRival;
    }
}

let opcion = parseInt(prompt("Elegi sabiamente a tu pokemon: \n1 - Bulbasaur \n2 - Charmander \n3 - Squirtle"));
let pokemonInicial = false;
let primerPokemon = elegirPokemon(opcion, pokemonInicial);
let pokemonRival = elegirPokemonRival(primerPokemon);

alert("¡Un rival aparecio y eligio a " + pokemonRival.nombre + "!");

let ganador = batallaPokemon(primerPokemon, pokemonRival);

if(ganador.nombre == primerPokemon.nombre){
    alert("¡Tu pokemon gano la batalla!");
} else {
    alert("¡El pokemon rival gano la batalla!");
}